package top.weidaboy.servicemain.mapper;

import top.weidaboy.servicemain.entity.Trip;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author vinda
 * @since 2020-12-07
 */
public interface TripMapper extends BaseMapper<Trip> {

}
