package top.weidaboy.servicemain.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import top.weidaboy.servicemain.entity.Student;
import top.weidaboy.servicemain.entity.Temp;
import com.baomidou.mybatisplus.extension.service.IService;
import top.weidaboy.servicemain.query.StudentQuery;
import top.weidaboy.servicemain.query.TempQuery;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author vinda
 * @since 2020-12-09
 */
public interface TempService extends IService<Temp> {
    List<Temp> getRandomTemp();
    public void pageQuery(Page<Temp> pageParam, TempQuery tempQuery) ;
    public void pagcheck(Page<Temp> pageParam, TempQuery tempQuery);
}
