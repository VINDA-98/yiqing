package top.weidaboy.servicemain.exception;

public class NormalException  extends  RuntimeException{
    public NormalException(String message){
        super(message);
    }
}
