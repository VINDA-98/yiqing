package top.weidaboy.servicemain.service;

public interface StudentVoService {

}
