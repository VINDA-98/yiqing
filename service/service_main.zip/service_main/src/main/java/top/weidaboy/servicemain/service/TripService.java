package top.weidaboy.servicemain.service;

import top.weidaboy.servicemain.entity.Trip;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author vinda
 * @since 2020-12-07
 */
public interface TripService extends IService<Trip> {

}
