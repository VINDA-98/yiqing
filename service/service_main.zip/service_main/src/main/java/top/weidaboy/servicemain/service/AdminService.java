package top.weidaboy.servicemain.service;

import top.weidaboy.servicemain.entity.Admin;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author vinda
 * @since 2020-12-07
 */
public interface AdminService extends IService<Admin> {

}
