package top.weidaboy.servicemain.service;

import top.weidaboy.servicemain.entity.Tourist;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author vinda
 * @since 2020-12-07
 */
public interface TouristService extends IService<Tourist> {

}
