package top.weidaboy.servicemain.service.impl;

import top.weidaboy.servicemain.entity.Tourist;
import top.weidaboy.servicemain.mapper.TouristMapper;
import top.weidaboy.servicemain.service.TouristService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author vinda
 * @since 2020-12-07
 */
@Service
public class TouristServiceImpl extends ServiceImpl<TouristMapper, Tourist> implements TouristService {

}
