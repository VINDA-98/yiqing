package top.weidaboy.servicemain.service.impl;

import top.weidaboy.servicemain.entity.Trip;
import top.weidaboy.servicemain.mapper.TripMapper;
import top.weidaboy.servicemain.service.TripService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author vinda
 * @since 2020-12-07
 */
@Service
public class TripServiceImpl extends ServiceImpl<TripMapper, Trip> implements TripService {

}
